<?php $__env->startSection('title', ' - Detail'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Barang</h1>
    </div>

    <div class="section-body">
        <div class="card shadow">
            <div class="card-header bg-white">
                <h4>View Data Barang</h4>
            </div>
            <div class="card-body">
                <form action="">
                    <form action="/barang/store" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col md 6">
                                <div class="form-group">
                                    <label for="kode">Kode</label>
                                    <input type="text" class="form-control" name="kode" value="<?php echo e($barang->kode); ?>"
                                        readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="nama">Nama</label>
                                    <input type="text" class="form-control" name="nama" value="<?php echo e($barang->nama); ?>"
                                        readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="kategori">Kategori</label>
                                    <input type="text" class="form-control" value="<?php echo e($barang->kategori->nama); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="satuan">Satuan</label>
                                    <input type="text" class="form-control" value="<?php echo e($barang->satuan->nama); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <div class="form-group">
                                        <label for="harga_beli">Harga Beli</label>
                                        <input type="number" class="form-control" name="harga_beli"
                                            value="<?php echo e($barang->harga_beli); ?>" readonly>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="harga_jual">Harga Jual</label>
                                    <input type="number" class="form-control" name="harga_jual"
                                        value="<?php echo e($barang->harga_jual); ?>" readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="stok">Stok</label>
                                    <input type="number" class="form-control" name="stok" value="<?php echo e($barang->stok); ?>"
                                        readonly>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="diskon">Diskon</label>
                                    <div class="input-group-prepend">
                                        <input type="number" class="form-control" name="diskon"
                                            value="<?php echo e($barang->diskon); ?>" readonly>
                                        <span class="input-group-text">%</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                    <div class="button">
                        <a href="/<?php echo e(auth()->user()->level); ?>/barang" class="btn btn-sm btn-outline-warning"><i class="fas fa-caret-left"></i>
                            Kembali</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/aplikasiweb/aplikasi-kasir/resources/views/barang/view.blade.php ENDPATH**/ ?>