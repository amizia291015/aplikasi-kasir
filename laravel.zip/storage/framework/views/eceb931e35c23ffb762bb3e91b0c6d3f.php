<?php $__env->startSection('title', ' - Edit'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Kategori</h1>
    </div>

    <div class="section-body">
        <div class="card">
            <div class="card-header bg-white">
                <h4>Edit Data Kategori</h4>
            </div>
            <div class="card-body">
                <form action="/<?php echo e(auth()->user()->level); ?>/kategori/<?php echo e($kategori->id); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" class="form-control" value="<?php echo e($kategori->nama); ?>" name="nama">
                    </div>
                    <a href="/<?php echo e(auth()->user()->level); ?>/kategori" class="btn btn-sm btn-outline-warning"><i class="fas fa-caret-left"></i> Kembali</a>
                    <button type="submit" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i> Edit</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/aplikasiweb/aplikasi-kasir/resources/views/kategori/edit.blade.php ENDPATH**/ ?>