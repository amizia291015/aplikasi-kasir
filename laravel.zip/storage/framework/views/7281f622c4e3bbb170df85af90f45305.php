<?php $__env->startSection('title', ' - Edit'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Barang</h1>
    </div>

    <div class="section-body">
        <div class="card shadow">
            <div class="card-header bg-white">
                <h4>Edit Data Barang</h4>
            </div>
            <div class="card-body">
                <form action="/<?php echo e(auth()->user()->level); ?>/barang/<?php echo e($barang->id); ?>" method="POST">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col md 6">
                            <div class="form-group">
                                <label for="kode">Kode</label>
                                <input type="text" class="form-control" name="kode" value="<?php echo e($barang->kode); ?>" disabled>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="nama">Nama</label>
                                <input type="text" class="form-control" name="nama" value="<?php echo e($barang->nama); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="kategori">Kategori</label>
                                <select class="custom-select" name="kategori_id">
                                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($kategori->id); ?>"
                                        <?php echo e($kategori->id == $barang->kategori_id ? 'selected' : ''); ?>>
                                        <?php echo e($kategori->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="satuan">Satuan</label>
                                <select class="custom-select" name="satuan_id">
                                    <?php $__currentLoopData = $satuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $satuan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($satuan->id); ?>"
                                        <?php echo e($satuan->id == $barang->satuan_id ? 'selected' : ''); ?>>
                                        <?php echo e($satuan->nama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <div class="form-group">
                                    <label for="harga_beli">Harga Beli</label>
                                    <input type="text" class="form-control jumlah" id="harga-beli" name="harga_beli"
                                        value="<?php echo e($barang->harga_beli); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="harga_jual">Harga Jual</label>
                                <input type="text" class="form-control jumlah" id="harga-jual" name="harga_jual"
                                    value="<?php echo e($barang->harga_jual); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="stok">Stok</label>
                                <input type="number" class="form-control jumlah" name="stok" value="<?php echo e($barang->stok); ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label for="diskon">Diskon</label>
                                <div class="input-group-prepend">
                                    <input type="text" class="form-control jumlah" id="diskon" name="diskon" value="<?php echo e($barang->diskon); ?>">
                                    <span class="input-group-text">%</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <a href="/<?php echo e(auth()->user()->level); ?>/barang" class="btn btn-sm btn-outline-warning"><i class="fas fa-caret-left"></i>
                        Kembali</a>
                    <button type="submit" class="btn btn-sm btn-outline-primary"><i class="fas fa-edit"></i>
                        Edit</button>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function () {
        $('.jumlah').on('input', function () {
            if ($(this).val() < 0) {
                $(this).val(0);
            }
        });
    });

    // Mengambil elemen input
    var harga_beli = document.getElementById('harga-beli');
    var harga_jual = document.getElementById('harga-jual');
    var diskon = document.getElementById('diskon');

    // Menambahkan event listener untuk setiap kali ada input
    harga_beli.addEventListener('input', function() {
      // Mengganti nilai input hanya dengan karakter angka
      this.value = this.value.replace(/[^0-9]/g, '');
    });

    // Menambahkan event listener untuk setiap kali ada input
    harga_jual.addEventListener('input', function() {
      // Mengganti nilai input hanya dengan karakter angka
      this.value = this.value.replace(/[^0-9]/g, '');
    });

    // Menambahkan event listener untuk setiap kali ada input
    diskon.addEventListener('input', function() {
      // Mengganti nilai input hanya dengan karakter angka
      this.value = this.value.replace(/[^0-9]/g, '');
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/aplikasiweb/aplikasi-kasir/resources/views/barang/edit.blade.php ENDPATH**/ ?>