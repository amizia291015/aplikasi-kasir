<!-- Modal -->
<div class="modal fade" id="data-barang" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title text-info" id="exampleModalLabel">Data Barang</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="card">
                    <div class="card-body">
                        <div style="overflow-y: scroll; max-height: 400px;">
                            <table class="table table-hover" id="table">
                                <thead>
                                    <tr>
                                        <th>No.</th>
                                        <th>Nama</th>
                                        <th>Harga</th>
                                        <th>Jumlah</th>
                                        <th>Stok</th>
                                        <th>Diskon</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <form action="/<?php echo e(auth()->user()->level); ?>/penjualan/store" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <td><?php echo e($loop->iteration); ?><input class="form-control" type="text"
                                                    value="<?php echo e($nomor); ?>" name="kode_transaksi" hidden></td>
                                            <td><?php echo e($item->nama); ?><input class="form-control" type="text"
                                                    value="<?php echo e($item->id); ?>" name="barang_id" hidden></td>
                                            <td><?php echo e($item->formatRupiah('harga_jual')); ?><input class="form-control"
                                                    type="text" value="<?php echo e($item->harga_jual); ?>" name="harga" hidden></td>
                                            <td style="width: 15%"><input class="form-control jumlah" type="number"
                                                    name="jumlah" id="jumlah" value="1" min="1" max="<?php echo e($item->stok); ?>">
                                            </td>
                                            <?php if($item->stok > 0): ?>
                                            <td><?php echo e($item->stok); ?><input type="text" value="<?php echo e($item->stok); ?>" hidden><input
                                                    class="form-control" type="text" value="1" hidden></td>
                                            <?php endif; ?>
                                            <?php if($item->stok <= 0): ?>
                                            <td><span class="text-danger">Stok Habis</span></td>
                                            <?php endif; ?>
                                            <td><?php echo e($item->diskon); ?>%<input class="form-control" type="text"
                                                    value="<?php echo e($item->diskon); ?>" name="diskon" hidden></td>
                                            <?php if($item->stok <= 0): ?>
                                            <td><button type="submit" id="tambah" class="btn btn-sm btn-success" disabled><i
                                                        class="fa fa-plus"></i></button></td>
                                            <?php endif; ?>
                                            <?php if($item->stok > 0): ?>
                                            <td><button type="submit" id="tambah" class="btn btn-sm btn-success"><i
                                                        class="fa fa-plus"></i></button></td>
                                            <?php endif; ?>
                                        </form>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Users/macbook/Documents/aplikasiweb/aplikasi-kasir/resources/views/penjualan/dataBarang.blade.php ENDPATH**/ ?>