<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2024 <div class="bullet"></div> Aplikasi Kasir
    </div>
</footer>
<?php /**PATH /Users/macbook/Documents/aplikasiweb/aplikasi-kasir/resources/views/layout/footer.blade.php ENDPATH**/ ?>