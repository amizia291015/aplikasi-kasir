<?php $__env->startSection('title', ' - Laporan'); ?>

<?php $__env->startSection('content'); ?>
<section class="section">
    <div class="section-header">
        <h1>Laporan</h1>
        <div class="section-header-breadcrumb">
            <div class="breadcrumb-item"><a href="/<?php echo e(auth()->user()->level); ?>/laporan">Laporan</a></div>
            <div class="breadcrumb-item">Cari Laporan</div>
        </div>
    </div>

    <div class="section-body">
        <div class="row">
            <div class="col-12">
                <div class="alert alert-success">
                    <p><span class="font-weight-bold">Laporan Tanggal: <?php echo e($dari); ?> Sampai <?php echo e($sampai); ?></span></p>
                </div>
                <div class="card shadow">
                    <div class="card-header bg-white justify-content-center">
                        <form action="/<?php echo e(auth()->user()->level); ?>/laporan/cari">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group d-flex">
                                        <label class="mr-1" for="nama">Dari</label>
                                        <input type="date" class="form-control" name="dari" value="<?php echo e($dari); ?>"
                                            max="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group d-flex">
                                        <label class="mr-1" for="nama">Sampai</label>
                                        <input type="date" class="form-control" name="sampai" value="<?php echo e($sampai); ?>"
                                            max="<?php echo date('Y-m-d'); ?>">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-sm btn-success"><i
                                                class="fa fa-search"></i> Cari</button>
                                        <a href="/<?php echo e(auth()->user()->level); ?>/laporan/<?php echo e($dari); ?>/<?php echo e($sampai); ?>/print" class="btn btn-sm btn-danger" target="_blank"><i
                                                class="fa fa-print"></i> Print</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="card-body p-2">
                        <table class="table table-hover" id="table">
                            <thead>
                                <tr>
                                    <th>No.</th>
                                    <th>Kode Transaksi</th>
                                    <th>Tanggal</th>
                                    <th>Kode Kasir</th>
                                    <th>Total</th>
                                    <th>Bayar</th>
                                    <th>Kembali</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->kode_transaksi); ?></td>
                                    <td><?php echo e($item->tanggal); ?></td>
                                    <td><?php echo e($item->kode_kasir); ?></td>
                                    <td><?php echo e($item->formatRupiah('total')); ?></td>
                                    <td><?php echo e($item->formatRupiah('bayar')); ?></td>
                                    <td><?php echo e($item->formatRupiah('kembali')); ?></td>
                                    <td>
                                        <a href="/<?php echo e(auth()->user()->level); ?>/laporan/<?php echo e($item->kode_transaksi); ?>/print" target="_blank"
                                            class="btn btn-sm btn-outline-danger"><i class="fa fa-print"></i> Print</a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script>
    $(document).ready(function () {
        $('#table').DataTable();
    });

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/macbook/Documents/aplikasiweb/aplikasi-kasir/resources/views/laporan/cari.blade.php ENDPATH**/ ?>